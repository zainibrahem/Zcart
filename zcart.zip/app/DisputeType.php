<?php

namespace App;

class DisputeType extends BaseModel
{
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'dispute_types';
}

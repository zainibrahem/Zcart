<?php

namespace App\Exceptions;

use InvalidArgumentException;

class PaymentConfigInvalid extends InvalidArgumentException
{
}

<?php

namespace App\Exceptions;

use Exception;

class PaymentFailedException extends Exception
{
    //
}

<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.1   |
    |              on 2021-03-01 09:45:29              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
* Copyright (C) Incevio Systems, Inc - All Rights Reserved
* Unauthorized copying of this file, via any medium is strictly prohibited
* Proprietary and confidential
* Written by Munna Khan <help.zcart@gmail.com>, September 2018
*/
 namespace App\Http\Controllers\Installer; use Illuminate\Http\Request; use App\Http\Controllers\Controller; use Illuminate\Support\Facades\Artisan; class WelcomeController extends Controller { public function welcome() { Artisan::call("\163\164\x6f\162\141\x67\x65\72\154\x69\156\x6b"); return view("\x69\156\x73\164\141\x6c\x6c\145\x72\x2e\x77\145\x6c\x63\157\155\x65"); } }
